$(document).ready(function(){
	 $(".menu").on("click",function(){
		$(".bar").animate({
		marginLeft:"0px"
		}, 100)
	});
	 
	$("html").on("click", function(e) {
		if(!$(e.target).is(".menu") && !$(e.target).is(".bar") && !$(e.target).parent().is(".bar") 
				&& !$(e.target).parent().parent().is(".bar")
				&& !$(e.target).parent().parent().parent().is(".bar")
				&& !$(e.target).parent().parent().parent().parent().is(".bar")) {
			$(".bar").animate({
				marginLeft:"-300px"
			}, 100);
		}
	});
	
	$("#resetBtn").on("click", function() {
		$("#productName").val("");
		$("#companyName").val("");
		$("#ingredientName").val("");
	});
	
	$(".searchBtn").on("click",function() {
		location.href = "medicineInfo_list.html";
	});
	
	$(".menuLoginBtn").on("click", function() {
		$(".menuNewAccount").css("display", "none");
		$(".menuLoginBtn").css("display", "none");
		$(".menuLogoutBtn").css("display", "inline-block");
		$(".menu_userId").css("display", "inline-block");
	});
	$(".menuLogoutBtn").on("click", function() {
		$(".menuNewAccount").css("display", "inline-block");
		$(".menuLoginBtn").css("display", "inline-block");
		$(".menuLogoutBtn").css("display", "none");
		$(".menu_userId").css("display", "none");
	});
});